"""Test Anthropic authentication without printing the API key."""

import json

from app.services.claude_client import ClaudeError, ping


def main() -> int:
    try:
        result = ping()
    except ClaudeError as exc:
        print(json.dumps({"status": "error", "detail": str(exc)}))
        return 1

    print(
        json.dumps(
            {
                "status": "connected",
                "model": result["model"],
                "request_id": result["request_id"],
                "response": result["text"],
                "usage": result["usage"],
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
